-- MODELO RELACIONAL. INTEGRIDAD DECLARATIVA. (SQL Est�ndar)
--1. Los tipos de planes son: Bas (B�sico), Pro (Pro) y Pre (Premium).

CREATE TABLE Planes(numero number(2) not null,nombre varchar(250),descripcion varchar(500) not null,precio decimal(8,2) not null,tipo varchar(20) not null);
ALTER TABLE Planes ADD CONSTRAINT CK_planes CHECK (nombre='Basico'or nombre='Premium' or nombre='Pro');

--2. Si la adquisici�n culmina, la fecha de retiro debe ser mayor a la fecha de adquisici�n.
CREATE TABLE Adquisiones(codigo number(3) not null,calificacion number(1) not null,observacion varchar(250),fechaAdquision date not null,fechaRetiro date);

CREATE OR REPLACE TRIGGER fecha
BEFORE UPDATE ON Adquisiones
for each row
    BEGIN
        if fechaRetiro='Null' THEN
         :new.fechaRetiro:='Null'
        else
         :new.fechaRetiro > old.fechaAdquision ;
    END if;
END fecha;
/

--3.La calificaci�n de cada adquisici�n debe estar entre 1 y 5
ALTER TABLE Adquisiones ADD CONSTRAINT CK_adquisiones CHECH(calificacion>0 and calificacion<6);

-- CONSTRUCCI�N (SQL ORACLE)
--1. Implemente la estructura de las tablas dise�adas en el punto 1. (sin restricciones de integridad externa)
CREATE TABLE acuedientes(codigoAc number(3)not null,nombre varchar(50));
CREATE TABLE clientes(codigo number(3) not null,nombre varchar(250)not null,correo varhcar(250),idiomavarhcar(50) not null);
CREATE TABLE usuarios(codigo  number(3) not null,codigoAc number(5),nickNam varchar(50));
CREATE TABLE organizaciones(codigo number(3) not null,contacto varchar(250)not null,telefono varchar(10]) not null);
CREATE TABLE creaciones(codigoUsuario number(3) not null,codigoCuest number(3) not null);
CREATE TABLE resportes(codigoOrganizacion number(3) not null, codigoUsuario number(3) not null);
CREATE TABLE selecciones(codigoUsu number(3) not null,codigoRes number(3) not null);
CREATE TABLE cuestionarios(codigo  number(3) not null,titulo varchar(50) not null,descripcion varchar(250) not null,fechaCreacion date not null);
CREATE TABLE respuestas(codigoRes number(3) not null,codigoPre number(3) not null, texto varchar(250)not null,esCorrecta varchar(6) not null);
CREATE TABLE preguntas(codigoCuest number(3) not null,codigoPre number(3) not null,texto  varchar(250)not null,puntos number(3));
CREATE TABLE adquisiones (codigo number(3) not null,calificacion number(1) not null,observacion varchar(250),fechaAdquision date not null,fechaRetiro date);
CREATE TABLE soluciones(codigo number(3) not null,nombre varchar(250) not null,descripcion varchar(500)not null,tipo varchar(20) not null);
CREATE TABLE planes(numero number(2) not null,nombre varchar(250),descripcion varchar(500) not null,precio  decimal(8,2) not null,tipo varchar(10) not null);

--FK
ALTER TABLE usuarios ADD CONSTRAINT FK_usuarios FOREIGN KEY (codigoAc) REFERENCES acudientes(codigoAc);
ALTER TABLE creaciones ADD CONSTRAINT FK_codigu FOREIGN KEY (codigoUsuario) REFERENCES usuarios(codigo);
ALTER TABLE creaciones ADD CONSTRAINT FK_codigc FOREIGN KEY (codigoCuest) REFERENCES cuestionarios(codigo);
ALTER TABLE reportes ADD CONSTRAINT FK_codigousu FOREIGN KEY (codigoUsuario) REFERENCES usuarios(codigo);
ALTER TABLE organizaciones ADD CONSTRAINT FK_codico FOREIGN KEY (codigo) REFERENCES clientes(codigo);
ALTER TABLE selecciones ADD CONSTRAINT FK_codigou FOREIGN KEY (codigoUsu) REFERENCES usuarios(codigo);
ALTER TABLE selecciones ADD CONSTRAINT FK_codigor FOREIGN KEY (codigoRes) REFERENCES respuestas(codigoRes);
ALTER TABLE respuestas ADD CONSTRAINT FK_codigop FOREIGN KEY (codigoPre) REFERENCES preguntas(codigoPre);
ALTER TABLE preguntas ADD CONSTRAINT FK_codigocuest FOREIGN KEY (codigoCuest) REFERENCES cuestionarios(codigo);
ALTER TABLE adquisiones ADD CONSTRAINT FK_numero FOREIGN KEY (nuemro) REFERENCES planes(numero);
ALTER TABLE selecciones ADD CONSTRAINT FK_codigoSol FOREIGN KEY (codigoSol) REFERENCES soluciones(codigo);

--PK
ALTER TABLE acudientes ADD PRIMARY KEY (codigoAc);
ALTER TABLE clientes ADD PRIMARY KEY (codigo);
ALTER TABLE usuarios ADD PRIMARY KEY (codigo);
ALTER TABLE creaciones ADD PRIMARY KEY (codigoUsuario,codigoCuest);
ALTER TABLE cuestionarios ADD PRIMARY KEY (codigo);
ALTER TABLE resportes ADD PRIMARY KEY (codigoOrganizacion,codigoUsuario);
ALTER TABLE organizaciones ADD PRIMARY KEY (codigo);
ALTER TABLE selecciones ADD PRIMARY KEY (codigoUsu,codigoRes);
ALTER TABLE respuestas ADD PRIMARY KEY (codigoRes);
ALTER TABLE pregguntas ADD PRIMARY KEY (codigoPre);
ALTER TABLE soluciones ADD PRIMARY KEY (codigo);
ALTER TABLE adquisiones ADD PRIMARY KEY (codigoAdq);
ALTER TABLE planes ADD PRIMARY KEY (numero);

--UK
ALTER TABLE clientes ADD UNIQUE (correo);
ALTER TABLE planes ADD UNIQUE (nombre);
ALTER TABLE soluciones ADD UNIQUE (nombre);